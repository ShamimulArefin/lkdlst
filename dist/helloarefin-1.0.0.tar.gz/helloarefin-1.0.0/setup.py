from setuptools import setup, find_packages

setup(
    name='helloarefin',
    version='1.0.0',
    author='Arefin',
    description='A simple math operations module',
    packages=find_packages(),
)